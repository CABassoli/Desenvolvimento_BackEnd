
package domain;

public enum StatusPedido {
    PENDENTE,
    CONFIRMADO,
    PROCESSANDO,
    ENVIADO,
    ENTREGUE,
    CANCELADO
}
