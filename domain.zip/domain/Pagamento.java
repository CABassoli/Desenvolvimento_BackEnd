
package domain;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public abstract class Pagamento {
    protected String id;
    protected String pedidoId;
    protected BigDecimal valor;
    protected LocalDateTime dataHora;
    protected boolean processado;

    public Pagamento() {
        this.dataHora = LocalDateTime.now();
        this.processado = false;
    }

    public Pagamento(String id, String pedidoId, BigDecimal valor) {
        this();
        this.id = id;
        this.pedidoId = pedidoId;
        this.valor = valor;
    }

    public abstract boolean processar();
    public abstract String getTipo();

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPedidoId() { return pedidoId; }
    public void setPedidoId(String pedidoId) { this.pedidoId = pedidoId; }

    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }

    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }

    public boolean isProcessado() { return processado; }
    public void setProcessado(boolean processado) { this.processado = processado; }
}
