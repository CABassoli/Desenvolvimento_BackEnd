
package domain;

import java.math.BigDecimal;

public class PagamentoCartao extends Pagamento {
    private String numeroCartao;
    private String nomeTitular;
    private String cvv;
    private String validade;
    private int parcelas;

    public PagamentoCartao() {}

    public PagamentoCartao(String id, String pedidoId, BigDecimal valor, String numeroCartao, 
                          String nomeTitular, String cvv, String validade, int parcelas) {
        super(id, pedidoId, valor);
        this.numeroCartao = numeroCartao;
        this.nomeTitular = nomeTitular;
        this.cvv = cvv;
        this.validade = validade;
        this.parcelas = parcelas;
    }

    @Override
    public boolean processar() {
        // Simulação do processamento do cartão
        System.out.println("Processando pagamento no cartão terminado em " + 
                          numeroCartao.substring(numeroCartao.length() - 4));
        this.processado = true;
        return true;
    }

    @Override
    public String getTipo() {
        return "CARTAO";
    }

    public String getNumeroCartao() { return numeroCartao; }
    public void setNumeroCartao(String numeroCartao) { this.numeroCartao = numeroCartao; }

    public String getNomeTitular() { return nomeTitular; }
    public void setNomeTitular(String nomeTitular) { this.nomeTitular = nomeTitular; }

    public String getCvv() { return cvv; }
    public void setCvv(String cvv) { this.cvv = cvv; }

    public String getValidade() { return validade; }
    public void setValidade(String validade) { this.validade = validade; }

    public int getParcelas() { return parcelas; }
    public void setParcelas(int parcelas) { this.parcelas = parcelas; }
}
