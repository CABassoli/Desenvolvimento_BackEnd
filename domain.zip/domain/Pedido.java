
package domain;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private String id;
    private String clienteId;
    private LocalDateTime dataHora;
    private StatusPedido status;
    private BigDecimal total;
    private String enderecoId;
    private List<ItemPedido> itens;

    public Pedido() {
        this.itens = new ArrayList<>();
        this.total = BigDecimal.ZERO;
        this.status = StatusPedido.PENDENTE;
        this.dataHora = LocalDateTime.now();
    }

    public Pedido(String id, String clienteId, String enderecoId) {
        this();
        this.id = id;
        this.clienteId = clienteId;
        this.enderecoId = enderecoId;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getClienteId() { return clienteId; }
    public void setClienteId(String clienteId) { this.clienteId = clienteId; }

    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }

    public StatusPedido getStatus() { return status; }
    public void setStatus(StatusPedido status) { this.status = status; }

    public BigDecimal getTotal() { return total; }
    public void setTotal(BigDecimal total) { this.total = total; }

    public String getEnderecoId() { return enderecoId; }
    public void setEnderecoId(String enderecoId) { this.enderecoId = enderecoId; }

    public List<ItemPedido> getItens() { return itens; }
    public void setItens(List<ItemPedido> itens) { this.itens = itens; }

    public void adicionarItem(ItemPedido item) {
        this.itens.add(item);
        recalcularTotal();
    }

    private void recalcularTotal() {
        this.total = itens.stream()
            .map(ItemPedido::getSubtotal)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
