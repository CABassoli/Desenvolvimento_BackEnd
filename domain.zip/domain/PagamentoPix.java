
package domain;

import java.math.BigDecimal;

public class PagamentoPix extends Pagamento {
    private String chavePix;
    private String qrCode;

    public PagamentoPix() {}

    public PagamentoPix(String id, String pedidoId, BigDecimal valor, String chavePix) {
        super(id, pedidoId, valor);
        this.chavePix = chavePix;
        this.qrCode = gerarQrCode();
    }

    @Override
    public boolean processar() {
        // Simulação do processamento do PIX
        System.out.println("PIX gerado para a chave: " + chavePix);
        System.out.println("QR Code: " + qrCode);
        this.processado = true;
        return true;
    }

    @Override
    public String getTipo() {
        return "PIX";
    }

    private String gerarQrCode() {
        // Simulação da geração do QR Code
        return "00020101021226580014BR.GOV.BCB.PIX" + System.currentTimeMillis();
    }

    public String getChavePix() { return chavePix; }
    public void setChavePix(String chavePix) { this.chavePix = chavePix; }

    public String getQrCode() { return qrCode; }
    public void setQrCode(String qrCode) { this.qrCode = qrCode; }
}
