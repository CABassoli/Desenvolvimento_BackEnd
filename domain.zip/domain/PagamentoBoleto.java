
package domain;

import java.math.BigDecimal;
import java.time.LocalDate;

public class PagamentoBoleto extends Pagamento {
    private String codigoBarras;
    private LocalDate dataVencimento;

    public PagamentoBoleto() {}

    public PagamentoBoleto(String id, String pedidoId, BigDecimal valor, LocalDate dataVencimento) {
        super(id, pedidoId, valor);
        this.dataVencimento = dataVencimento;
        this.codigoBarras = gerarCodigoBarras();
    }

    @Override
    public boolean processar() {
        // Simulação da geração do boleto
        System.out.println("Boleto gerado com código de barras: " + codigoBarras);
        System.out.println("Data de vencimento: " + dataVencimento);
        this.processado = true;
        return true;
    }

    @Override
    public String getTipo() {
        return "BOLETO";
    }

    private String gerarCodigoBarras() {
        // Simulação da geração do código de barras
        return "23793.39126 60000.000000 00000.000000 0 " + System.currentTimeMillis();
    }

    public String getCodigoBarras() { return codigoBarras; }
    public void setCodigoBarras(String codigoBarras) { this.codigoBarras = codigoBarras; }

    public LocalDate getDataVencimento() { return dataVencimento; }
    public void setDataVencimento(LocalDate dataVencimento) { this.dataVencimento = dataVencimento; }
}
